var x = 1;
while(x < 52){
	document.write(x + ", ");
	x = x + 2;
}