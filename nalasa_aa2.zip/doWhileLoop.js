var x = 2
do{
	document.write(x + ", ");
	x = x + 2;
}while(x < 51)