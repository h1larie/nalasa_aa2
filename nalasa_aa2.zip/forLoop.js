for(let x = 1, y = 1; x < 4108; y--){
	x = (x * 2) + y;
	document.write(x + ", ");
}
